<?php

$config = include '../config.php';
$apiUrl = 'https://api.worldota.net/api/b2b/v3/hotel/order/cancel/';
$keyId = $config['api_key'];
$apiKey = $config['api_password'];

$ch = curl_init($apiUrl);

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$path = $_SERVER['DOCUMENT_ROOT']; 

include_once $path . '/wp-load.php';

global $wpdb;

$wpdb->show_errors();
$prefix = $wpdb->prefix;

if (!isset($_POST['order_id'])){
    error_log("Invalid request");
    echo 'Invalid request';
    exit();
}

try{
    $order_id = $_POST['order_id'];
    
    $partner_order_id = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT meta_value FROM {$wpdb->prefix}postmeta WHERE post_id = %d AND meta_key = %s",
            $order_id,
            'partner_order_id'
        )
    );
    
    $body_data = array(
        'partner_order_id' => $partner_order_id
    );
    
    $data = json_encode($body_data);
    
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Basic ' . base64_encode("$keyId:$apiKey")
    ]);
    
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    
    $response = curl_exec($ch);
    
    if(curl_errno($ch)) {
        error_log('Curl error: ' . print_r(curl_error($ch), true));
    }else{
        $responseData = json_decode($response, true);
        error_log(print_r($responseData, true));
        echo $responseData['status'];
    }
    
    curl_close($ch);
    
}catch (\Exception $ex){
    error_log($ex->getMessage());
}
?>