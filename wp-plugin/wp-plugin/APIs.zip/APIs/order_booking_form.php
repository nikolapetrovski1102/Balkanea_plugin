<?php

$keyId = '7788';
$apiKey = 'e6a79dc0-c452-48e0-828d-d37614165e39';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$path = $_SERVER['DOCUMENT_ROOT']; 

include_once $path . '/wp-load.php';

global $wpdb;

$wpdb->show_errors();
$prefix = $wpdb->prefix;

if (!isset($_POST['data']) && !isset($_POST['type']) ) {
    return 'Error: No data and type provided.';
}

$errorMessages = [
    'block' => 'Card authorization blocked.',
    'charge' => 'Card authorization failed.',
    '3ds' => 'Invalid 3D-secure code.',
    'soldout' => 'The rate is no longer available as rooms at this rate are sold out.',
    'book_limit' => 'Booking failed due to cut-off logic.',
    'provider' => 'Technical error at the rate provider.',
    'order_not_found' => 'No reservation found for the given partner_order_id.',
    'booking_finish_did_not_succeed' => 'Order Booking Finish failed without success.',
    'timeout' => 'Request timed out.',
    'unknown' => 'An unknown error occurred.',
    '5xx' => 'Server error (5xx status code).',
];

$stopErrors = array_keys($errorMessages);

$data = $_POST['data'];
$type = $_POST['type'];
$current_ip = $_SERVER['REMOTE_ADDR'];

function ConvertCurrency($price_expode_currency){
    switch ($price_expode_currency[0]):
        case '€':
            return $price_expode_currency[1];
        case 'MKD':
            return  $price_expode_currency[1] / 61.53;
    endswitch;
}

function UpdatePrice ($price, $room_id, $prefix, $wpdb) {
    error_log("Update price");
    error_log($price);
    error_log($room_id);
    try {
        
        $wpdb->update(
            $prefix . 'postmeta',
            array(
                'meta_value' => $price
            ),
            array(
                'post_id' => $room_id,
                'meta_key' => 'price'
            ),
            array('%f'),
            array('%d', '%s')
        );

        if ($wpdb->last_error){
                error_log("/home/balkanea/public_html/wp-plugin/APIs/order_booking_form.php:52");
                error_log($wpdb->last_error);
                throw new \Exception($wpdb->last_error);
        }

    }catch (\Exception $ex){
        error_log("/home/balkanea/public_html/wp-plugin/APIs/order_booking_form.php:58");
        error_log($ex->getMessage());
        exit();
    }
}

if ($type === 'prebook'){
 
    $apiUrl = 'https://api.worldota.net/api/b2b/v3/hotel/prebook/';

    $ch = curl_init($apiUrl);
    
    $body_data = array(
        "hash" => $data,
        "price_increase_percent" => 0
    );
    
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Basic ' . base64_encode("$keyId:$apiKey")
    ]);
    
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body_data));
    
    $response = curl_exec($ch);

    curl_close($ch);

    if ($response === false){
        error_log(print_r(curl_error($ch), true));
        echo 'error';
    }
    else{
        $response = json_decode($response, true);
        
        error_log(print_r($response, true));
        error_log($response['data']['hotels'][0]['rates'][0]['daily_prices'][0]);
        
        if ($response['status'] == 'error'){
            error_log(print_r($response, true));
        }else{
            $changes = $response['data']['changes'] ?? false;
            if ($changes['price_changed'] == false)
                echo 'false';
            else
                echo 'true';
        }
    }
    
}
else if ($type === 'order_booking_form'){

    try{
        
        $apiUrl = 'https://api.worldota.net/api/b2b/v3/hotel/order/booking/form/';

        $ch = curl_init($apiUrl);

        if (!isset($data['price']) && !isset($data['room_id']) &&  !isset($data['book_hash'])){
            error_log("/home/balkanea/public_html/wp-plugin/APIs/order_booking_form.php:Line 120");
            error_log("Data is missing");
            error_log(json_encode($data, true));
            exit();
        }
        
        $price = $data['price'];
        $room_id = $data['room_id'];
        $book_hash = $data['book_hash'];
        $order_data = $data['order_data'];
        
        error_log("Data: ");
        error_log(print_r($data, true));
        
        $price_expode_currency = explode(' ', $price);

        $price = ConvertCurrency($price_expode_currency);

        UpdatePrice($price, $room_id, $prefix, $wpdb);

        $partner_order_id = time();

        $cookie_name = "partner_order_id";
        $cookie_value = $partner_order_id;

        setcookie($cookie_name, $cookie_value, time() + 600, "/", "", true, false);
        setcookie($cookie_value . '_order_data', $order_data, time() + 600, "/", "", true, false);

        $body_data = array(
            "partner_order_id" => $partner_order_id,
            "book_hash" => $book_hash,
            "language" => "en",
            "user_ip" => $current_ip
        );
        
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Basic ' . base64_encode("$keyId:$apiKey")
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body_data));

        // $response = curl_exec($ch);

        curl_close($ch);

        if ($response === false){
            error_log('Curl error: ' . curl_error($ch));
            echo 'error';
        }
        else{
            $response = json_decode($response, true);

            if ($response['status'] == 'ok'){
                setcookie($partner_order_id, json_encode($response['data']['payment_types'][0]), time() + 600, "/", "", true, false);
                echo $response['status'];
            }
            else{
                error_log("/home/balkanea/public_html/wp-plugin/APIs/order_booking_form.php:Line 180");
                error_log(print_r($response, true));
                echo $response['status'];
            }
        }
        }catch (\Exception $ex){
            error_log("/home/balkanea/public_html/wp-plugin/APIs/order_booking_form.php:185");
            error_log($ex->getMessage());
            exit();
        }
}
else if ($type === 'order_booking_finish' && is_numeric($data)){

    try{
        $query = $wpdb->prepare("SELECT * FROM {$wpdb->prefix}postmeta WHERE post_id = %d", $data);

        $datarate = $wpdb->get_results($query);
        
        $orderData = [];
        foreach ($datarate as $item) {
            $orderData[$item->meta_key] = $item->meta_value;
        }
        
        if ($orderData['partner_order_id'] == "" || $orderData['partner_order_id'] == null){
            error_log('not-provider');
            exit();
        }
    
        $order_data_json = $orderData['_order_data'] ?? '';

        if (isset($order_data_json) && $order_data_json != ''){
            $jsonString = str_replace("\\", "", $order_data_json);
            $order_data = json_decode($jsonString, true);
        }
        
        $guestNames = [];
        foreach ($order_data as $entry) {
            if ($entry['name'] === 'guest_name[]') {
                $guestNames[] = $entry['value'];
            }
        }
    
        $guests = [];
        foreach ($guestNames as $name) {
            $nameParts = explode(' ', $name, 2);
            $guests[] = [
                'first_name' => $nameParts[0] ?? '',
                'last_name' => $nameParts[1] ?? ''
            ];
        }

        $cleaned_json = stripslashes($orderData['payment_details']);
        $payment_type_json = json_decode($cleaned_json, true);

        $apiUrl = 'https://api.worldota.net/api/b2b/v3/hotel/order/booking/finish/';

        $ch = curl_init($apiUrl);

        $body_data = array(
            "user" => array(
                'email' => $orderData['_billing_email'],
                'comment' => 'TEST',
                'phone' => '+389 71 326 943',
            ),
            "supplier_data" => array(
                "first_name_original" => $orderData['_billing_first_name'],
                "last_name_original" => $orderData['_billing_last_name'],
                "phone" => $orderData['_billing_phone'],
                "email" => $orderData['_billing_email']
            ),
            "partner" => array(
                "partner_order_id" => $orderData['partner_order_id'],
                "comment" => ""
            ),
            "language" => "en",
            "rooms" => array(
                array(
                    "guests" => $guests
                )
            ),
            "payment_type" => $payment_type_json
        );

        $json_result = json_encode($body_data, JSON_PRETTY_PRINT);

        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Basic ' . base64_encode("$keyId:$apiKey")
        ]);
        
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json_result);

        $response = curl_exec($ch);

        curl_close($ch);

        if ($response === false){
            error_log(print_r($response, true));
            error_log('Curl error: ' . curl_error($ch));
        }
        else{
            $response = json_decode($response, true);
        
            if ($response['status'] == 'ok'){
                
                $apiUrl = 'https://api.worldota.net/api/b2b/v3/hotel/order/booking/finish/status/';
    
                do {
                    $ch = curl_init($apiUrl);
                
                    $bodyData = array(
                        "partner_order_id" => $orderData['partner_order_id'],
                    );
                
                    curl_setopt($ch, CURLOPT_HTTPHEADER, [
                        'Content-Type: application/json',
                        'Authorization: Basic ' . base64_encode("$keyId:$apiKey")
                    ]);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($bodyData));
                
                    $response = curl_exec($ch);
                    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    curl_close($ch);
                
                    if ($response === false) {
                        error_log('Curl error: ' . curl_error($ch));
                        break;
                    }
                
                    $responseData = json_decode($response, true);
                
                    if (!isset($responseData['status'])) {
                        error_log("Unexpected response: " . print_r($response, true));
                        // $order->update_status('failed', 'Order marked as failed after unsuccessful API response.');
                        // echo 'error';
                        break;
                    }
                
                    $status = $responseData['status'];
                    $error = isset($responseData['error']) ? $responseData['error'] : null;
                
                    if ($status === 'ok') {
                        error_log("Successful order #{$data}");
                        // echo $status;
                            // $order_id = $data;
                            // $order = wc_get_order($order_id);

                            // if ($order) {
                            //     $order->update_status('completed', 'Order marked as completed after successful API response.');
                            //     error_log("Order with ID {$order_id} marked as completed.");
                            // } else {
                            //     error_log("Failed to retrieve order with ID: {$order_id}");
                            // }

                        break;
                    }
                
                   if (in_array($error, $stopErrors)) {
                        error_log("Order with ID: {$data} has status {$error} from RateHawk");
                        $errorMessage = $errorMessages[$error] ?? 'An unspecified error occurred.';
                        error_log("Stopped due to error: $error - $errorMessage");
                        // $order->update_status('failed', 'Order marked as failed after unsuccessful API response.');
                        
                        // if ($order) {
                        //     $order->update_status('completed', 'Order marked as completed after successful API response.');
                        //     error_log("Order with ID {$order_id} marked as completed.");
                        // } else {
                        //     error_log("Failed to retrieve order with ID: {$order_id}");
                        // }
                        
                        // return [
                        //     'error' => $error,
                        //     'message' => $errorMessage,
                        // ];
                    }
                
                    if ($httpCode >= 500 && $httpCode < 600) {
                        error_log("Stopped due to server error: HTTP $httpCode");
                        // $order->update_status('failed', 'Order marked as failed after unsuccessful API response.');
                        break;
                    }
                
                    sleep(1);
                
                } while (true);

            }
            else{
                error_log("/home/balkanea/public_html/wp-plugin/APIs/order_booking_form.php:Line 323");
                // $order->update_status('failed', 'Order marked as failed after unsuccessful API response.');
                error_log(print_r($response, true));
                // echo $response['status'];
            }
        }
    }catch (\Exception $ex){
        error_log("/home/balkanea/public_html/wp-plugin/APIs/order_booking_form.php:Line 328");
        // $order->update_status('failed', 'Order marked as failed after unsuccessful API response.');
        error_log($ex->getMessage());
        exit();
    }
    
    }else{
        error_log("/home/balkanea/public_html/wp-plugin/APIs/order_booking_form.php:Line 334");
        error_log("Incorrect body");
        error_log($data);
    }
    
    exit();

?>