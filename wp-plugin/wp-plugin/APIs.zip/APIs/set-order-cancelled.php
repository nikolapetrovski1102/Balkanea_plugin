<?php
require_once($_SERVER['DOCUMENT_ROOT'] . '/wp-load.php');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!class_exists('WooCommerce')) {
    die(json_encode(['success' => false, 'message' => 'WooCommerce is not active.']));
}

// Read the raw input data and decode it
$raw_input = file_get_contents('php://input');
$data = json_decode($raw_input, true);

// Validate the order_id
if (!isset($data['order_id']) || empty($data['order_id'])) {
    die(json_encode(['success' => false, 'message' => 'Order ID is required.']));
}

$order_id = intval($data['order_id']);

try {
    $order = wc_get_order($order_id);
    error_log($order_id);

    if (!$order) {
        error_log("Order not found");
        die(json_encode(['success' => false, 'message' => "Order with ID {$order_id} not found."]));
    }

    error_log("Order found: " . $order_id);

    if ($order->get_status() === 'cancelled') {
        die(json_encode(['success' => false, 'message' => "Order ID {$order_id} is already cancelled."]));
    }

    if (in_array($order->get_status(), ['processing', 'completed'])) {
        $order->update_status('cancelled', 'Order was cancelled programmatically.');
    }

    echo json_encode(['success' => true, 'data' => 'ok']);
} catch (Exception $e) {
    error_log('Error cancelling order: ' . $e->getMessage());
    die(json_encode(['success' => false, 'message' => 'Failed to cancel order: ' . $e->getMessage()]));
}
?>
