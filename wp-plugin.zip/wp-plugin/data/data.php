<?php

$data_hotel = [
    '24396' => [ // Greece
        '6140790' => [
            'cronwell_platamon_resort_2'
        ],
        '603217' => [ 
            'toroni_blue_sea_hotel'
        ],
        '965842500' => [
            'aqua_mare_hotel_2',
            'aegean_blue_hotel'
        ],
        '6131021' => [
            'olympus_thalassea_hotel'
        ],
        '181071' => [
            'bemyguest_plus_villa_chrisanhti'
        ],
        '6265993' => [
            'crown_hotel_27'
        ],
        '8876576' => [
            'test_hotel'
        ],
        '3186' => [
            'hotel_el_greco',
            'test_hotel_do_not_book'
        ],
    ],
    '16479' => [ // Serbia
        '6156549' => [
            'apartmani_u_borovoj_sumi',
            'zlatibor_hills_stars',
            'titova_vila_zlatibor',
            'villa_natural_wood',
            'monix_club_zlatibor',
            'brvnara_vranjevina_zlatibor',
            'zlatibor_residence',
            'brvnare_mir_zlatibor'
        ],
        '965835355' => [
            'kopaonik',
            'nicole_kopaonik',
            'hotel_olga_dedijer_kopaonik',
            'kopaonik_house_',
            'hotel_club_a_kopaonik'
        ]
    ],
    '1231231' => [ // Bulgaria
        '6046713' => [
            'kap_house_hotel',
            'grand_royale_apartment_complex__spa',
            'studio_chalet_13_st_john_park_bansko',
            'predela_lux',
            'bansko_apartment_at_belvedere_holiday_club',
            'alpine_lodge_hotel_2',
            '7_pools_boutique_hotel_spa_2',
            'saint_george_palace_apartments_spa',
            'bansko_royal_towers_hotel_2',
            'belvedere_holiday_club',
            'belvedere_holiday_club_l102',
            'belvedere_holiday_club_106g',
            'belvedere_holiday_club_k302',
            'bansko_apartment_at_belvedere_holiday_club',
            'downtown_alexander_services_apartments',
            'st_anastasia_apartments'
        ]
    ]
]

?>