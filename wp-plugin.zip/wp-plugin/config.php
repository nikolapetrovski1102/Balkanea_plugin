<?php
return [
    'api_key' => '7788',
    'api_password' => 'e6a79dc0-c452-48e0-828d-d37614165e39',
    'email' => 'admin@balkanea.com'
];
